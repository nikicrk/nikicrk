# SCREENSHOT
![IMG_20210321_105642](https://user-images.githubusercontent.com/80812572/111893271-2cd4ad00-8a34-11eb-94b0-89bcdca8d0a1.jpg)

# INSTALL
```
$ pkg update
$ pkg upgrade
$ pkg install python
$ pkg install python2
$ pip2 install requests
$ pip2 install mechanize
$ pip2 install lolcat
$ pip2 install bs4
$ pkg install git
```
# RUN
```
$ git clone https://https://github.com/Boy-Tolkit/flash
$ cd flash
$ ls
$ python2 crack.c
```
# METODE LOGIN
- Token
- Manual
